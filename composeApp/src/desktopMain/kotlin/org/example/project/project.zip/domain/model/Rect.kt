package org.example.project.domain.model

data class Rect(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)